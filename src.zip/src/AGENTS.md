# Source Architecture

## Structure
```
src/
   middleware.ts           # Server-side deeplink parameter validation (400 for invalid)
   wagmi.ts               # Web3 configuration with chain configs and RainbowKit setup
   components/            # Reusable UI components (� AGENTS.md)
   lib/                   # Core utilities and validation (� AGENTS.md)
   pages/                 # Next.js route handlers for deeplinks (� AGENTS.md)
   styles/                # CSS modules and global styles
```

## Core Modules

### Validation Pipeline
- `middleware.ts` - Server-side parameter validation using deeplink specs
- `lib/deeplink.ts` - Generic validation with typed specs (addr/int/dec/str)
- `lib/deeplinkSpecs.ts` - Route-specific validation rules

### Transaction Flow
- Pages validate params � render UI � connect wallet � encode actions � submit proposal
- `ProposalMetadata.tsx` - IPFS metadata upload via `/api/ipfs` endpoint
- `ProposalActionButton.tsx` - Contract interaction with loading states

### Web3 Integration
- wagmi + viem for Ethereum interactions
- RainbowKit for wallet connection
- Multi-chain support with NetworkSwitcher component
- Contract ABIs for Aragon OSx plugins and CogniSignal

## Entry Points
- `/merge-change` - Git PR approval proposals
- `/join` - DAO token faucet claims  
- `/propose-faucet` - Permission grants for faucet setup

## Security
- Host validation on IPFS upload endpoint
- Client-side contract existence checks
- Parameter validation at middleware and component levels